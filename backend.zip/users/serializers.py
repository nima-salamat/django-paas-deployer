from rest_framework import serializers,  exceptions
from .models import User, Profile, Rule, COLOR_CHOICES
from django.contrib.auth.password_validation import validate_password
from django.core.exceptions import ValidationError as DjangoValidationError
import json
import string

class CreateUserSerializer(serializers.ModelSerializer):
    email = serializers.EmailField(required=False, allow_blank=True)
    username = serializers.CharField(max_length=150, required=True)
    phone_number = serializers.CharField(
        max_length=11,
        required=False,
        allow_blank=True,
    )

    class Meta:
        model = User
        fields = ["username", "email", "phone_number"]
        extra_kwargs = {
            "username": {"write_only": True},
            "email": {"write_only": True},
            "phone_number": {"write_only": True}
        }

    def validate(self, data):
        if not data.get("email") and not data.get("phone_number"):
            raise serializers.ValidationError("Either email or phone number must be set.")

        # email = data.get("email")
        # phone_number = data.get("phone_number")
        
        
        # MAX_PER_EMAIL = 2
        # MAX_PER_PHONE = 2
        
        # if email:
        #     count = User.objects.filter(email=email).count()
        #     if count >= MAX_PER_EMAIL:
        #         raise serializers.ValidationError({"email": f"too many accounts registered with this email {email}"})
        

        # if phone_number:
        #     count = User.objects.filter(phone_number=phone_number).count()
        #     if count >= MAX_PER_PHONE:
        #         raise serializers.ValidationError({"phone_number": f"too many account registered with this phone number {phone_number}"})

        return data  

        
    def create(self, validated_data):
        username = validated_data.get("username", "")
        email = validated_data.get("email", "")
        phone_number = validated_data.get("phone_number", "")
        data = {}
        if username:
            data["username"] = username
        if email:
            data["email"] = email
        if phone_number:
            data["phone_number"] = phone_number
        user = User(
            **data,
            is_active=False
        )
        
        try:
            user.full_clean() 
            user.save()
        except DjangoValidationError as e:
            raise exceptions.ValidationError(e.message_dict)
        except Exception as e:
            raise exceptions.ValidationError(e)
            
        return user
        
class GetUserSerializer(serializers.ModelSerializer):
    has_password = serializers.SerializerMethodField(read_only=True)

    class Meta:
        model = User
        fields = ["id", "username", "email", "phone_number", "theme", "email_verified", "phone_number_verified", "color", "birthdate", "has_password", "is_staff", "is_superuser"]
        extra_kwargs = {
            "id" : {"read_only": True},
            "username": {"read_only": True},
            "email" : {"read_only": True},
            "phone_number" : {"read_only": True},
            "theme": {"read_only": True},
            "color": {"read_only": True},
            "email_verified": {"read_only": True},
            "email_verified": {"read_only": True},
            "birthdate": {"read_only": True},
        }

    def get_has_password(self, obj):
        return obj.has_usable_password()

class SetPasswordSerializer(serializers.Serializer):
    new_password = serializers.CharField(write_only=True, min_length=8)
    new_confirm_password = serializers.CharField(write_only=True, min_length=8)

    def validate(self, data):
        if data["new_password"] != data["new_confirm_password"]:
            raise serializers.ValidationError("Passwords do not match.")
        validate_password(data["new_password"])
        return data

    def save(self, user):
        if user.has_usable_password():
            raise serializers.ValidationError("Password already set. Use change password instead.")
        user.set_password(self.validated_data["new_password"])
        user.save()
        return user

class ChangePasswordSerializer(serializers.Serializer):
    current_password = serializers.CharField(write_only=True, min_length=8)
    new_password = serializers.CharField(write_only=True, min_length=8)
    new_confirm_password = serializers.CharField(write_only=True, min_length=8)

    def __init__(self, *args, **kwargs):
        self.user = kwargs.pop("user", None)
        super().__init__(*args, **kwargs)

    def validate(self, data):
        if data["new_password"] != data["new_confirm_password"]:
            raise serializers.ValidationError("Passwords do not match.")
        if not self.user or not self.user.check_password(data["current_password"]):
            raise serializers.ValidationError("Current password is incorrect.")
        validate_password(data["new_password"], user=self.user)
        return data

    def save(self):
        self.user.set_password(self.validated_data["new_password"])
        self.user.save()
        return self.user

class RemovePasswordSerializer(serializers.Serializer):
    current_password = serializers.CharField(write_only=True, min_length=8)

    def __init__(self, *args, **kwargs):
        self.user = kwargs.pop("user", None)
        super().__init__(*args, **kwargs)

    def validate(self, data):
        if not self.user or not self.user.check_password(data["current_password"]):
            raise serializers.ValidationError("Current password is incorrect.")
        if not self.user.has_usable_password():
            raise serializers.ValidationError("No password is configured for this account.")
        return data

    def save(self):
        self.user.set_unusable_password()
        self.user.save()
        return self.user

class UpdateUserSerializer(serializers.Serializer):
    email = serializers.EmailField(required=False, allow_blank=False)
    username = serializers.CharField(max_length=150, required=False)
    phone_number = serializers.CharField(
        max_length=11,
        allow_blank=True,
        required=False
    )
    
    birthdate = serializers.DateField(required=False, allow_null=True)
    theme = serializers.ChoiceField(choices=User.ThemeChoices.choices)
    color = serializers.ChoiceField(choices=COLOR_CHOICES)

    def validate(self, data):
        return CreateUserSerializer.validate(self, data)
    def update(self, user, data):
        username = data.get("username", None)
        phone_number = data.get("phone_number", None)
        email = data.get("email", None)
        birthdate = data.get("birthdate", None)
        theme = data.get("theme", None)
        color = data.get("color", None)
        
        if username is not None:
            user.username = username
        if phone_number is not None:
            user.phone_number = phone_number
            user.phone_number_verified=False
            
        if email is not None:
            user.email = email
            user.email_verified=False
        if birthdate is not None:
            user.birthdate = birthdate
        if color is not None:
            user.color = color
        if theme is not None:
            user.theme = theme
   
        try:
            user.full_clean() 
            user.save()
        except DjangoValidationError as e:
            raise exceptions.ValidationError(e.message_dict)
        except Exception as e:
            raise exceptions.ValidationError(e)
        return user


class AddImageProfileSerializer(serializers.Serializer):
    image = serializers.ImageField(write_only=True)
    order = serializers.IntegerField(write_only=True)
    
    def save(self, user):
        order = self.validated_data.get("order", -1)
        profile = Profile(user=user, order=order, image=self.validated_data["image"])
        try:
            profile.full_clean() 
            profile.save()
        except DjangoValidationError as e:
            raise exceptions.ValidationError(e.message_dict)
        except Exception as e:
            raise exceptions.ValidationError(e)
        return profile
    
    
class OrderImageProfileSerializer(serializers.Serializer):
    order = serializers.JSONField(write_only=True)
    def validate(self, data):
        order = data.get("order", None)
        if order and isinstance(order, dict):
            if not all([i.isdigit() for i in order.keys()]):
                raise exceptions.ValidationError("order keys should be inlcude digits")
            if not all([isinstance(i, int) for i in order.values()]):
                raise exceptions.ValidationError("order values should be a integer")
        else:
            raise exceptions.ValidationError("order should be a dict(json=>{key:value}) that is not empty")
        return data 
    def save(self, user):
        profile_images =  Profile.objects.filter(user=user)
        profile_images = {str(i.id):i for i in profile_images}
        order = self.validated_data["order"]
        for i in order:
            try:
                profile_images[i].order = int(order[i])
                profile_images[i].save()
            except KeyError:
                pass
        return order
    
class ProfileImagerSerializer(serializers.ModelSerializer):
    image_url = serializers.SerializerMethodField(read_only=True)

    class Meta:
        model = Profile
        fields = ["id", "order", "image_url"]

    
                
    def get_image_url(self, obj):
        # Return RELATIVE URL so the browser resolves against the current page
        # origin (HTTPS). build_absolute_uri() returned http:// URLs when Django
        # sat behind an HTTPS reverse proxy forwarding http:// in Host header,
        # which caused Mixed Content errors on the messenger page.
        if obj.image and hasattr(obj.image, "url"):
            try:
                return obj.image.url
            except Exception:
                return None
        return None
    
    
class DeletePasswordSerializer(serializers.Serializer):
    password = serializers.CharField(write_only = True, min_length=8)
    confirm_password = serializers.CharField(write_only = True, min_length=8)

    def is_valid(self, *, raise_exception=False, user=None):
        self.user = user
        return super().is_valid(raise_exception=raise_exception)
    
    def validate(self, data):
        
        if data["password"] != data["confirm_password"]:
            raise serializers.ValidationError("Password do not match")
        
        if not self.user.check_password(data["password"]):
            raise serializers.ValidationError("Password is not correct")

        return data

    def save(self):

        self.user.password = ""
        self.user.save()
        return self.user
    