from django.db import models, transaction
from django.contrib.auth.models import AbstractBaseUser, UserManager
from phonenumber_field.modelfields import PhoneNumberField
from django.core.exceptions import ValidationError
from django.utils.translation import gettext_lazy as _
from django.contrib.postgres.fields import ArrayField
from django.utils import timezone
from core.global_settings.config import COLOR_CHOICES, PaymentChoices
from users.validators import ImageValidator
import uuid
import random



class PermissionMixin(models.Model):
    is_superuser = models.BooleanField(
        _("superuser status"),
        default=False,
        help_text=_(
          "User has all permissions without explicitly assigning them."
        )
    )
    
    class Meta:
        abstract = True
    def has_perm(self, perm, obj=None):
        return self.is_active and self.is_superuser
    
    def has_perms(self, perm_list, obj=None):
        return self.is_active and self.is_superuser
    
    def has_module_perms(self, app_label):
        return self.is_active and self.is_superuser

def get_uuid():
    return uuid.uuid4().hex



def get_color():
    
    return random.choice(COLOR_CHOICES)[0]
    

class User(AbstractBaseUser, PermissionMixin):
    class ThemeChoices(models.TextChoices):
        DARK  = "dark",  _("Dark")
        LIGHT = "light", _("Light")

    uuid = models.CharField(max_length=32, editable=False, null=False, blank=False, unique=True, default=get_uuid)
    username = models.CharField(_("username"), unique=True, max_length=32, 
        help_text=_("Required. 32 characters or fewer. Include numbers, letters and ./-/_ characters."),
    )
    password = models.CharField(_("password"), max_length=128, blank=True, null=True)
    email = models.EmailField(_("email address"), max_length=255, null=True, blank=True, unique=True)
    email_verified = models.BooleanField(_("email verified"), default=False)
    phone_number = PhoneNumberField(_("phone number"), null=True, blank=True, unique=True)
    phone_number_verified = models.BooleanField(_("phone number verified"), default=False)
    theme = models.CharField(_("theme"), choices=ThemeChoices.choices, default=ThemeChoices.LIGHT, max_length=7)
    color = models.PositiveSmallIntegerField(_("color"), choices=COLOR_CHOICES, default=get_color)    
    birthdate = models.DateField(_("birth date"),null=True, blank=True)
    balance = models.DecimalField(max_digits=11, decimal_places=3, default=0)
    is_staff = models.BooleanField(
        _("staff status"),
        default=False,
        help_text=_("Designates whether the user can log into this admin site."),
    )
    is_active = models.BooleanField(
        _("active"),
        default=True,
        help_text=_(
            "Designates whether this user should be treated as active. "
            "Unselect this instead of deleting accounts."
        ),
    )
    date_joined = models.DateTimeField(_("date joined"), default=timezone.now)
    national_id = models.CharField(_("National Id"), max_length=11, blank=True, null=True)

    USERNAME_FIELD = "username"
    REQUIRED_FIELDS = ["email"]
    objects = UserManager()
    
    class Meta:
        ordering = ["username"]
        verbose_name = "user"
        verbose_name_plural = "users"



class Receipt(models.Model):
    user = models.ForeignKey(User, verbose_name=_("User Receipt"),on_delete=models.CASCADE, related_name="receipts", related_query_name="receipt")
    amount = models.DecimalField(_("Amount"), max_digits=11, decimal_places=3)
    created_at = models.DateTimeField(auto_now_add=True)
    updated_at = models.DateTimeField(auto_now=True)
    status = models.CharField(_("Payment Status"), max_length=10, choices=PaymentChoices.choices, default=PaymentChoices.NOT_PAYED)
    
    @classmethod
    def change_balance(cls, receipt):
        with transaction.atomic():
            user = receipt.user
            user.balance += receipt.amount
            receipt.status = PaymentChoices.PAYED
            user.save()
            receipt.save()
    

class Profile(models.Model):
    order = models.IntegerField(_("Order"), default=0)
    user = models.ForeignKey(User,verbose_name=_("User Profile"), on_delete=models.CASCADE)
    image = models.ImageField(upload_to="images",verbose_name=_("Profile Image"), validators=[ImageValidator(size_kb=2048, max_w=2560, max_h=1440)])
    created_at = models.DateTimeField(default=timezone.now)
    def clean(self):
        if self.pk is None:
            if Profile.objects.filter(user=self.user).count() >= 5:
                raise ValidationError(_("A user can have at most 5 profiles."))
            
    def save(self, *args, **kwargs):
        self.full_clean()
        super().save(*args, **kwargs)

    def __str__(self):
        return f"{self.user}-{self.order}"


class Rule(models.Model):
    user = models.OneToOneField(User, on_delete=models.CASCADE, verbose_name= _("user rule"), related_name="rule")
    rules = ArrayField(
        base_field=models.CharField(max_length=100),
        blank=True,
        default=list
    )
    updated_at = models.DateTimeField(auto_now=True)
    created_at = models.DateTimeField(default=timezone.now)
    
    def __str__(self):
        return f"{self.user.username}"
    