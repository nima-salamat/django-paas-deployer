from dataclasses import dataclass, field
from typing import Any, Callable, Optional


EventSink = Callable[["DeploymentEvent"], None]


@dataclass(frozen=True)
class NetworkSpec:
    name: str
    driver: str = "bridge"
    internal: bool = True
    attachable: bool = True


@dataclass(frozen=True)
class VolumeSpec:
    source: str
    target: str
    mode: str = "rw"
    mount_type: str = "volume"
    driver: str = "local"
    driver_opts: dict[str, Any] = field(default_factory=dict)
    create: bool = True
    size_mb: Optional[int] = None


@dataclass(frozen=True)
class DeploymentConfig:
    name: str
    tag: str
    zip_path: str
    dockerfile_template: str
    max_cpu: float
    max_ram: int
    networks: list[NetworkSpec]
    volumes: list[VolumeSpec]
    port: Optional[int]
    read_only: bool
    platform: str
    platform_type: str
    # --- new fields ---------------------------------------------------------
    # Runtime environment variables injected at container start (not baked
    # into the image).  Keys and values must both be strings.
    environment: dict[str, str] = field(default_factory=dict)
    # Override ASGI/WSGI detection for Django ("asgi" | "wsgi" | None).
    # When None the entrypoint is auto-detected from the source code.
    server_type: Optional[str] = None
    # When True, a Celery worker process is added to the container via
    # supervisord alongside the web server.
    celery: bool = False
    # When True (requires celery=True), a Celery beat scheduler process is
    # also added to the supervisord configuration.
    celery_beat: bool = False
    # When non-empty, this fully replaces the auto-generated CMD instruction
    # in the Dockerfile.  Use this as an escape hatch for custom entrypoints.
    entry_point: Optional[str] = None
    # Number of web-server / Celery worker processes. Default 1.
    # Overridable via Deploy.config["worker_count"].
    worker_count: int = 1
    # ------------------------------------------------------------------------
    stop_timeout: int = 15
    start_timeout: int = 45
    health_timeout: int = 60
    health_interval: float = 1.0

    @property
    def image_ref(self) -> str:
        return f"{self.name}:{self.tag}"


@dataclass
class DeploymentEvent:
    stage: str
    message: str
    level: str = "info"
    progress: Optional[int] = None
    details: dict[str, Any] = field(default_factory=dict)


@dataclass
class DeploymentResult:
    success: bool
    status: str
    message: str
    image_ref: Optional[str] = None
    container_name: Optional[str] = None
    previous_image_ref: Optional[str] = None
    rollback_performed: bool = False
    # Explicit flag so callers can distinguish "deploy failed, but
    # rollback restored the previous container" from "deploy failed AND
    # rollback itself failed" (the service is now without a container).
    rollback_failed: bool = False
    error: Optional[str] = None
    stage: Optional[str] = None
    details: dict[str, Any] = field(default_factory=dict)

